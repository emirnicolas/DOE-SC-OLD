import scrapy
from doescfinal.items import Links
import pdfplumber


class DoescSpider(scrapy.Spider):
    name = 'doesc2'
    allowed_domains = ['doe.sea.sc.gov.br/index.php/buscar-jornal/']
    start_urls = ['http://doe.sea.sc.gov.br/index.php/buscar-jornal//']

    def parse(self, response):
        article = response.css('div.ml-3 a::attr(data-downloadurl)').getall()[1]
        pdf_url = article
        notice = Links(pdf_url=pdf_url)
        yield notice

        

